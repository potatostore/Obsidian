---
tags:
  - seed
aliases: []
created: 2025-07-10
---
# 관계형 데이터베이스

#### 수직확작성(Scale-Up)

#### 수평확장성(Scale-Out)

#### 왜 관계형 데이터베이스는 빅데이터에 적합하지 않은가


# 비관계형 데이터베이스



# Amazon RDS

#### Amazon RDS Read Replica

- 수평 확장성

