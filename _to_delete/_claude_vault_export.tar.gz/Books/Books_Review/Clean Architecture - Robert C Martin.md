---
title: Clean Architecture
subtitle: A Craftsman's Guide to Software Structure and Design
author: Robert C. Martin
authors: Robert C. Martin
category: Computers
categories: Computers
publisher: Pearson Professional
publishDate: 2018
totalPage: 404
coverUrl: http://books.google.com/books/content?id=8ngAkAEACAAJ&printsec=frontcover&img=1&zoom=1&source=gbs_api
coverSmallUrl: http://books.google.com/books/content?id=8ngAkAEACAAJ&printsec=frontcover&img=1&zoom=5&source=gbs_api
description: Building upon the success of best-sellers The Clean Coder and Clean Code, legendary software craftsman Robert C. &quot;Uncle Bob&quot; Martin shows how to bring greater professionalism and discipline to application architecture and design. As with his other books, Martin's Clean Architecture doesn't merely present multiple choices and options, and say &quot;use your best judgment&quot;: it tells you what choices to make, and why those choices are critical to your success. Martin offers direct, is essential reading for every software architect, systems analyst, system designer, and software manager-- and for any programmer who aspires to these roles or is impacted by their work.
link: https://books.google.com/books/about/Clean_Architecture.html?hl=&id=8ngAkAEACAAJ
previewLink: http://books.google.co.kr/books?id=8ngAkAEACAAJ&dq=Clean+Architecture&hl=&as_pt=BOOKS&cd=1&source=gbs_api
isbn10: 134494164
isbn13: 9780134494166
tags:
  - CS
  - include
  - inlcude
aliases: []
created: 2026-03-29
---
---
Clean Architecture이란 Clean Code로 만들어진 벽돌은 무지성으로 쌓아올리는 것이 아닌 가장 효율적이고 정갈하게 쌓는 것이다.

특히 책에서 밝히는 목표는 유지보수가 가능한 코드를 작성하므로서 추후에 발생하는 비용을 절감하는데 의의를 둔다.

이 책은 프로그래밍의 기초를 천천히 알려주며, 추후에 어떤 점을 개선하거나, 어떻게 코드를 쌓아 올려야 유지보수가 가능한 코드가 가능한지 알려주는 것이며, 코드가 클린하다는 점을 전제로 깔고 가기에 [[Clean Code]]를 병행하며 읽으면 시너지가 발생한다는 점을 쉽게 이해할 수 있다.

개발자는 코드 작성만이 중요한 것이 아니다. 코드를 어떻게 쌓아올리는지에 따라 유지보수의 방향성이 달라지고, 이는 곧 소프트웨어 전체적인 부분에 영향을 줄 것이다.

# 1. 설계와 아키텍처
 

아키텍처를 한글로 번역하게 되면 설계가 되지 않을까? 라는 의문과 함께 설계와 아키텍처를 같은 동의어로 이해하고 넘어가는 경우가 많다.

- 아키텍처 : 저수준의 세부사항과는 분리되는 고수준의 무언가를 가르킴
- 설계 : 저수준의 구조 또는 결정사항 등을 의미함

여기까지가 책에 저술된 내용인데, 상당히 모호한 표현이라고 생각이 된다.

프로젝트의 저수준과 고수준의 경계선이 매우 모호하기 때문이다.

흔히 *고수준*이라는 단어를 사용하게 되면 전체적인 면이라고 생각할 수 있다. 

이를 바탕으로 좀 더 구체화하면 프로젝트를 구상할 때, 어떤 기능들을 구현할 것인가?에 대한 것은 고수준이며, 이 기능들을 어떻게 구현할까? 라는 것은 저수준이라고 생각할 수 있다.

그렇기에 아키텍처를 시스템 전체적인 구조와 기능, 그리고 그 기능들의 관계를 가르킨다고 볼 수있고,
설계는 그 기능들을 어떻게 구현할 것인지에 대해 구상화하는 것을 말한다고 볼 수 있다.

그렇다면 위 내용들을 바탕으로 설계에 대한 방식과 규칙을 유도하는 규칙이 [[Clean Code]]이고, 이 설계를 바탕으로 유기적인 소프트웨어를 제작하는 방법을 알려주는 책이 [[Clean Architecture]]라고 이해할 수 있다.

저자가 밝히기를 이 책을 쓴 이유는 시스템의 유지보수를 하는데 필요한 인력을 최소화한다라고 볼 수 있다.

# 2. 두 가지 가치에 대한 이야기
 

모든 소프트웨어 시스템은 개발자에 의해 개발이 되고, 이에 대한 가이드를 이해관계자(관리자 등)에게 넘김으로서 프로그램의 유지보수를 맡긴다.

이때 개발자는 유지관계자에게 두 가지 가치를 제공해야하는데, 이를 *행위*와 *구조*이다.

- 행위(behavior) : 개발된 프로그램이 어떤 가치를 갖고, 어떤 기능을 실현시킬 수 있는지
- 구조(architecture) : 개발된 프로그램이 어떤 구조를 갖고 있는지

위 두 가지 가치를 지니고 있어야 온전한 소프트웨어가 발생한다.

본래 소프트웨어는 부드러운이라는 형용사가 붙은 만큼 기계의 행위가 쉽게 변할 수 있도록 개발해야 한다.

그렇다면 소프트웨어는 두 가치 중 어떤 것이 더 중요할까?

볼 것도 없이 당연히 구조이다.

아이젠하워 매트릭스가 말하길 세상에는 4가지 종류의 문제가 있다고 했다.

1. 긴급하고, 중요한 문제
2. 긴급하지는 않지만, 중요한 문제
3. 긴급하지만, 중요하지는 않은 문제
4. 둘 다 아닌 문제

위 순서대로 중요도를 갖는다고 주장했는데, 긴급한 문제는 중요도를 뺴먹을 수 있지만, 중요한 문제는 긴급하지 않더라도 나중에 프로그램의 성능면에서 큰 부분을 차지할 수도 있다고 생각하기 때문이다.

# 3. 패러다임 개요

패러다임이란 프로그래밍을 하는 방법이다.

다양한 방법이 존재하겠지만, 우리에게 익숙한 것들은 OOP, 절차지향 프로그래밍, 함수형 프로그래밍 등이 존재한다.

이 책에서는 세 가지의 패러다임을 중요시 여기는데, 구조적 프로그래밍, 객체 지향 프로그래밍, 함수형 프로그래밍이다.

## 구조적 프로그래밍
 
- 데이크스트라가 goto와 같은 점프문을 코드에 해롭다는 사실을 인지하고, 이를 if~else/while등의 점프로 바꾸었다.
- 제어흐름의 직접적인 제어에 대한 규칙을 부과한다.

## 객체 지향 프로그래밍
 
- 구조적 프로그래밍보다 2년 앞선 시기에 등장한 개념으로, 함수 호출 스택 프레임을 힙 영역에 옮기게 되면 함수가 반환되어도 함수에서 사용된 지역변수가 남아있다는 것을 발견한 후 착안된 개념이다.
- 제어흐름의 간접적인 제어에 대한 규칙을 부과한다.

## 함수형 프로그래밍
 
- 불변성을 근간으로 둔 람다 계산법을 통해 변수를 까다로운 조건에서 할당하고, 초기화를 하더라도 변화하는데 큰 제약을 부여하는 방식이다. 비교적 최근에 조명받았지만, 사실 가장 먼저 착안된 개념이다.
- 할당문에 규칙을 부과한다

책의 내용은 상당히 이해하기 어렵게 작성이 되었는데, 각 패러다임이 무엇이고, 어떤 규칙을 부과하는지에 대한 서술은 이해가 되지만, 각 패러다임이 세상에 나오게 된 계기가 무엇인지 모르고, 그러기에 기초한 개념에 대한 이해가 상당히 어려웠다.

핸드폰을 꺼내 검색을 시작하려던 시점에 다음 목차가 *구조적 프로그래밍*인 것을 확인하고 굉장히 잘 짜여있는 책임을 다시 한번 확인했다.

# 4. 구조적 프로그래밍
 

데이크스트라는 1950년대, 아직 프로그래밍이라는 직업이 탄생하지 않고, 하나의 공학으로 인정받지 않던 시절에 프로그램을 작성하면서 많은 프로그래머들이 프로그래밍을 잘하지 못한다는 사실을 인지하고, 프로그램이 아주 작은 세부사항이라도 놓지게 되면 오류를 불러 일으킨다는 점을 인지했다.

수학이라는 증명을 통해 참임을 밝히는 학문을 통해 데이크스트라는 이를 해결하려고 노력했다.

그가 사용하는 방식은 유클리드의 계층구조이다.

*유클리드 계층구조 : 공리라는 증명이 없어도 항상 참으로 받아들여지는 명제를 뜻한다. 이러한 공리가 만들어지기 위해 정리라는 증명을 통해  참이라는 것이 밝혀진 명제들이 필요했고, 이러한 구조를 만드는 것을 뜻한다.*

즉 입증된 구조를 통해 코드를 작성하고, 이를 통해 코드가 입증되었다는 것을 스스로 증명하게 만들고 싶었던 것이다.

그 과정에서 간단한 알고리즘부터 증명하는 과정을 거쳐야 가능한데, 이는 상당히 힘든 과정이다.

연구 과정에서 goto문장이 모듈을 더 작은 단위로 재귀적으로 분해하는 과정에 방해가 되는 경우가 있다는 사실을 발견하였다.

만약 모듈을 분해하지 못한다면 합리적으로 증명할 때 필수적으로 사용되는 기법인 *분할 정복 접근법*을 사용하지 못한다.

그는 goto문장을 사용하더라도 모듈을 분해할 때 문제가 되지 않는 경우들을 분석하였고, 이는 if/else/do/while과 같이 분기와 반복이라는 단순한 제어 구조에 해당한다는 사실을 발견하였다. goto문은 코드흐름을 해당 코드로 이동하기에 개발자 본인이 작성을 하였더라도, 추후에 컴파일이 작동했을 때, 흐름을 파악하기 쉽지 않았다. 데이크스트라는 이를 해결하기 위해 위 조건문 위주의 프로그래밍을 주장했고, 언론에 알려진 직후 반발이 심했지만, 추후에 goto문이 점차 사라지면서 증명해냈다. 즉 goto문을 굳이 사용하지 않더라도 goto문을 좋은 방면으로 사용한 것과 동일한 효과를 발생할 수 있다는 점이다.

수학은 참을 증명하는 학문이고, 과학은 거짓을 증명하는 학문이라는 소리가 있다.

과학은 F=ma처럼 참임을 증명할 방법은 없지만, 이를 부정할 논리가 없으므로 참이라고 내세운다.
즉 과학은 추후에 거짓으로 언제든지 증명될 수 있는 학문이라는 것이다. 데이크스트라가 유클리드 계층구조를 통해 위 goto문 대신 반복/제어문을 사용하는 것이 더 효율적이라는 것은 과학적인 방법으로 증명을 하는 것과 동일한 것이다.

추후에 데이크스트라는 테스트 또한 동일하게 코드가 정답임을 나타내 줄 수는 없지만, 코드가 틀렸다는 것을 보여주는 것이라고 주장했다.

이는 테스트주도개발을 통해 참임을 증명하지 말고, 거짓이 없음을 증명하는 것을 시도해야 한다는 뜻이다.

*구조적 프로그래밍 : 기존의 goto문을 지양하고, 반복/제어문을 통해 제약을 걸어 제어흐름의 직접적인 제어에 대한 규칙을 부여하는 것*

# 5. 객체 지향 프로그래밍

객체 지향을 설명하라고 하면 많은 이들이 객체지향의 특징을 생각해낸다.

객체 지향하면 바로 떠오를 정도로 기억되는 4가지의 기능이 있다.(책에서는 3가지만 소개)

1. 캡슐화
2. 상속
3. 다형성
4. 추상화(책에서 소개 x)

과연 우리는 위 4가지의 특징이 객체지향을 설명해준다는 것을 증명할 수 있을까?

## 캡슐화

캡슐화는 private, public 연산자를 통해 외부에서 멤버 변수, 메서드에 접근하지 못하도록 막거나, 개방하는 것을 뜻한다. 즉 클래스 외부에서 생성된 객체를 통해 priavte선언된 멤버변수에 접근을 못한다는 것이다.

여기서 핵심은 private 연산자가 아닌 외부에 생성된 객체에 멤버변수가 접근하지 못하도록 만들면 캡슐화가 이루어졌다고 말할 수 있다.

다음 c코드를 살펴보자

```c title='Point.h'
struct Point;
struct Point* makePoint(double x, double y);
double distance(struct Point* p1, struct Point* p2);
```

```c title='main.c'
#include "Point.h"
#inlcude <stdlib.h>
#include <stdio.h>

struct Point{
	double x,y;
}

struct Point* makePoint(double x, double y){
	struct Point* p = malloc(sizeof(struct Point));
	p->x = x;
	p->y = y;
	return p;
}

double distance(struct Point* p1, struct Point p2){
	double dx = p1->x - p2->x;
	double dy = p1->y - p2->y;
	return sqrt(dx*dx + dy*dy);
}
```

point.h를 사용하는 측에서 struct Point의 멤버에 접근을 할 수가 없다.

1. "Point.h"에 struct Point는 존재만 알려줄 뿐, 멤버변수에 대한 선언문이 존재하지 않는다.
2. 클라이언트 코드에서 struct Point에 대한 정의를 해도 해당 구조체에 직접접근(p.x / p.y)를 하는 것이 아닌 간접접근을 통해 접근을 함.

즉 절차지향 언어에서 객체지향 언어의 private와 동일한 효과를 보이는 코드를 작성할 수 있다는 뜻이다.

이를 c++의 캡슐화를 통해 코드를 작성해보면

```cpp title='point.h'
class Point{
public :
	Point(double x, double y);
	double distance(const Point& p) const;

private : 
	double x;
	double y;
}
```

```c++ title='point.cc'
#include "point.h"
#include <math.h>

Point::Point(double x, double y) : x(x), y(y)
{}

double Point::distancde(coinst Point& p) const{
	double dx = x - p.x;
	double dy = y - p.y;
	return sqrt(dx*dx - dy*dy);
}
```

위와 같이 클래스 내부에 private, public을 넣어 캡슐화를 간편히 하였지만, 클래스에 생성자를 넣어 놓으므로서 멤버변수가 존재한다는 사실을 클라이언트 입장에서 확인할 수 있다.

즉 객체 지향 언어가 절차 지향 언어보다 캡슐화가 안되어 있다는 것을 확인할 수 있다.

protected등의 키워도를 추가하는 방식으로 불완전한 캡슐화를 어느 정도 보완했지만, 자바/c#과 같이 헤더와 구현체를 분리하는 방식을 버리는 언어는 캡슐화를 오히려 더 훼손시켰다.

따라서 객체 지향이 강력한 캡슐화를 지원하는 것은 틀린말이다.
(물론 객체지향이 캡슐화 기능을 위한 키워드들을 지원하는 것은 사실이다.)

## 상속


 


# 6. 함수형 프로그래밍


# 7.  SRP : 단일 책임 원칙


# 8. OCP : 개방-폐쇄 원칙


# 9. LSP : 리스코프 치환 원칙


# 10. ISP : 인터페이스 분리 원칙


# 11. DIP : 의존성 역전 원칙


# 12. 컴포넌트


# 13. 컴포넌트 응집도


# 14. 컴포넌트 결합


# 15. 아키텍처


# 16. 독립성


# 17. 경계 : 선 긋기


# 18. 경계 해부학


# 19. 정책과 수준


# 20. 업무 규칙


# 21. 소리치는 아키텍처


# 22. 클린 아키텍처


# 23. 프레젠터와 험블 객체


# 24. 부분적 경계


# 25. 계층과 경계


# 26. 메인 컴포넌트


# 27.  크고 작은 모든 서비스들


# 28. 테스트 경계


# 29. 클린 임베디드 아키텍처


# 30. 데이터베이스는 세부사항이다


# 31. 웹은 세부사항이다


# 32. 프레임워크는 세부사항이다


# 33. 사례 연구 : 비디오 판매


# 34. 빠져 있는 잠

