---
tags:
  - seed
aliases: []
created: 2025-10-09
---
MongoDB는 현존하는 모든 비관계형 데이터베이스 중 개발자가 선호하는 서비스 1위이다.

SQL은 아니지만 간단한 쿼리문을 지원하며, 이를 CLI 환경에서 편집이 가능하도록 mongosh와 같은 shell program을 지원하기에 개발자의 선호를 받는 것 같다. 

사실 데이터베이스는 